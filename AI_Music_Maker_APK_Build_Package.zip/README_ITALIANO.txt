AI MUSIC MAKER — progetto Android v3

Questa versione aggiunge un tentativo di collegamento diretto a Gemini API / Lyria:
- Lyria 3 Clip per richieste da 30 secondi
- Lyria 3.5 per canzoni di circa un paio di minuti
- riproduzione e download MP3 quando l'API restituisce l'audio
- campo per inserire la propria chiave API nella schermata

ATTENZIONE:
1. Non è incluso alcun APK compilato.
2. Non è inclusa una chiave API: devi crearla dal sito ufficiale Google AI Studio.
3. Disponibilità, prezzi, quote e accesso al modello dipendono dall'account.
4. Per sicurezza, non pubblicare un'app che contiene una chiave API; per distribuzione reale serve un backend protetto.
5. La registrazione vocale è solo un campione da riascoltare: non clona la tua voce.
6. La durata è un'indicazione nel prompt; il modello non garantisce esattamente 1/2/3 minuti.
7. La chiamata API diretta da WebView può essere limitata dall'ambiente Android o dal servizio; se fallisce, serve un backend/server intermedio.

Per provare: apri progetto in Android Studio, compila APK, avvia app e inserisci la tua chiave Gemini API. Non condividere la chiave.
Documentazione ufficiale: https://ai.google.dev/gemini-api/docs/music-generation


BUILD APK SENZA PC (usando GitHub dal telefono):
1. Crea/accedi a un account GitHub.
2. Crea un repository nuovo e carica i contenuti di questo ZIP (devi estrarre lo ZIP prima di caricare i file).
3. Apri la scheda Actions del repository.
4. Se compare la richiesta di abilitare Actions, abilitala.
5. Seleziona "Build AI Music Maker APK" e premi "Run workflow".
6. Quando il lavoro finisce con successo, apri la sua esecuzione, scorri fino ad Artifacts e scarica "AI-Music-Maker-debug-apk".
7. Estrai l'APK dal file ZIP scaricato e installalo sul telefono. Android potrebbe chiedere di autorizzare l'installazione da quella fonte.

Nota: il workflow compila il progetto ma non verifica che l'API musicale sia attiva per il tuo account. L'APK è una build di prova/debug, non una versione pubblicata sul Play Store.
